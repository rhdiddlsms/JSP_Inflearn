package com.servlet;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/tsc")
public class TestServletClass extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("--doGet() 메소드!--");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	// init() : 로그인 아이디와 패스워드를 변수에 담는다던가, 공통적으로 이루어지는 업무를 init단계에서 많이함
	// destroy() : 데이터베이스 사용후 자원해재 및 웹서버 리소스를 사용후 반납 할 때 사용됨. 
	
	@PostConstruct
	public void funPc() {
		System.out.println("--@PostConstruct-- ");
	}
	
	@Override
	public void init() throws ServletException {
		System.out.println("--init() 메소드!--");
	}
	
	@Override
	public void destroy() {
		System.out.println("--destroy() 메소드!--");
	}
	
	@PreDestroy
	public void funPd() {
		System.out.println("--@PreDestroy-- ");
	}

}
