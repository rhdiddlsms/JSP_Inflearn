package com.servlet;

import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/mSignUp")
public class MemSignUp extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println(" -- doGet() -- ");
		
		String m_name = request.getParameter("m_name"); //어떠한 값 하나만 꺼낼 때 getParameter사용 ("")의 내용은 (name = "여기있는 내용")이 들어감.
		String m_pass = request.getParameter("m_pass");
		String m_gender = request.getParameter("m_gender");
		String[] m_hobbys = request.getParameterValues("m_hobby"); //들어오는 값을 배열로 받을 수 있음. 여러개의 데이터를 받을 때 getParameterValues로 받음
		String m_residence = request.getParameter("m_residence");
		
		System.out.println("m_name : " + m_name);
		System.out.println("m_pass : " + m_pass);
		System.out.println("m_gender : " + m_gender);
		System.out.println("m_hobbys : " + Arrays.toString(m_hobbys));
		System.out.println("m_residence : " + m_residence);
		
		
		// front에서 파라미터가 어떻게 날라오는지 확인하고 싶을 때 name의 속성값을 알고 싶으면 아래의 문장 사용하기.
		Enumeration<String> names = request.getParameterNames(); // getParameterNames사용
		while (names.hasMoreElements()) {
			String name = (String) names.nextElement();
			System.out.println("name : " + name);
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println(" -- doPost() -- ");
		
		doGet(request, response); // doGet메소드를 부름, doGet으로 들어오든 doPost로 들어오던 같음
	}

}
